# MEGO RPG Android

This app is intentionally a thin Android WebView wrapper around the live MEGO RPG GitHub Pages site:

https://mohamed797-ux.github.io/mego-study/

The website code is NOT bundled into the APK. Edit the site on GitHub and the app will load the updated live site.

Build: GitHub Actions -> Build MEGO RPG APK -> Artifact `MEGO-RPG-APK`.
